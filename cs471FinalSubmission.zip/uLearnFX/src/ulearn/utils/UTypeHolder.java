package ulearn.utils;

public class UTypeHolder {
	String userType;

	public UTypeHolder() { }

	public String getUserType() { return userType; }

	public void setUserType(String userType) { this.userType = userType; }
}
