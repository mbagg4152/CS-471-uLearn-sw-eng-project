package ulearn.controllers;

import javafx.scene.control.Button;

public class ClassTeacherCont {
    public Button chatsvhomesubmit;
    public Button chatsvhomesubmit1;
    public Button chatsvhomesubmit2;
    public Button chatsvhomesubmit3;
    public Button chatsvhomesubmit4;
}
